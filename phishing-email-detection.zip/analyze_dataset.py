#!/usr/bin/env python3
"""Summarize a CSV email dataset and compare it with the rule-based detector."""

from __future__ import annotations

import argparse
from collections import Counter
import csv
import json
from pathlib import Path
import sys

from phishing_detector import analyze_email


TEXT_COLUMNS = ("email", "message", "body", "text", "content", "raw_email", "mail")
LABEL_COLUMNS = ("label", "class", "target", "category", "is_phishing")
PHISHING_LABELS = {"1", "phishing", "phish", "malicious", "fraudulent", "unsafe"}
LEGITIMATE_LABELS = {"0", "legitimate", "legit", "ham", "benign", "safe"}


def pick_column(headers: list[str], requested: str | None, candidates: tuple[str, ...]) -> str | None:
    by_lower = {header.casefold(): header for header in headers}
    if requested:
        if requested.casefold() not in by_lower:
            raise ValueError(f"column {requested!r} was not found; available columns: {', '.join(headers)}")
        return by_lower[requested.casefold()]
    return next((by_lower[name] for name in candidates if name in by_lower), None)


def normalize_label(value: str) -> bool | None:
    normalized = value.strip().casefold()
    if normalized in PHISHING_LABELS:
        return True
    if normalized in LEGITIMATE_LABELS:
        return False
    return None


def analyze_rows(rows: list[dict[str, str]], text_column: str, label_column: str | None, threshold: int) -> dict:
    risk_counts: Counter[str] = Counter()
    indicator_counts: Counter[str] = Counter()
    label_counts: Counter[str] = Counter()
    score_total = 0
    evaluated = skipped_labels = blank_rows = 0
    tp = fp = fn = tn = 0

    for row in rows:
        raw_email = (row.get(text_column) or "").strip()
        if not raw_email:
            blank_rows += 1
            continue
        result = analyze_email(raw_email)
        score_total += result["score"]
        risk_counts[result["risk"]] += 1
        indicator_counts.update(signal["code"] for signal in result["signals"])
        predicted_phishing = result["score"] >= threshold

        if label_column:
            actual = normalize_label(row.get(label_column) or "")
            if actual is None:
                skipped_labels += 1
            else:
                evaluated += 1
                label_counts["phishing" if actual else "legitimate"] += 1
                if actual and predicted_phishing:
                    tp += 1
                elif not actual and predicted_phishing:
                    fp += 1
                elif actual and not predicted_phishing:
                    fn += 1
                else:
                    tn += 1

    scanned = sum(risk_counts.values())
    report: dict[str, object] = {
        "rows_scanned": scanned,
        "blank_rows_skipped": blank_rows,
        "risk_counts": {risk: risk_counts.get(risk, 0) for risk in ("High", "Suspicious", "Low")},
        "average_rule_score": round(score_total / scanned, 2) if scanned else 0,
        "most_common_indicators": [
            {"indicator": code, "count": count}
            for code, count in indicator_counts.most_common(10)
        ],
        "label_counts": dict(label_counts),
        "unrecognized_labels_skipped": skipped_labels,
        "positive_score_threshold": threshold,
    }
    if label_column:
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        report["evaluation"] = {
            "rows_with_recognized_labels": evaluated,
            "true_positive": tp,
            "false_positive": fp,
            "false_negative": fn,
            "true_negative": tn,
            "accuracy": round((tp + tn) / evaluated, 4) if evaluated else None,
            "precision": round(precision, 4) if evaluated else None,
            "recall": round(recall, 4) if evaluated else None,
            "f1": round(2 * precision * recall / (precision + recall), 4) if precision + recall else (0.0 if evaluated else None),
        }
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Summarize a CSV of emails and report detector performance when labels are present.")
    parser.add_argument("dataset", help="Path to a CSV file containing email text.")
    parser.add_argument("--text-column", help="Column with the email text; otherwise common names are detected automatically.")
    parser.add_argument("--label-column", help="Optional column with phishing/legitimate labels; auto-detected when present.")
    parser.add_argument("--threshold", type=int, default=3, help="Score at or above which an email counts as a positive detection (default: 3).")
    parser.add_argument("--limit", type=int, help="Analyze only the first N data rows.")
    parser.add_argument("--out", help="Optional path to save the report as JSON.")
    args = parser.parse_args()

    try:
        with open(args.dataset, "r", encoding="utf-8-sig", newline="") as dataset_file:
            reader = csv.DictReader(dataset_file)
            headers = reader.fieldnames or []
            if not headers:
                raise ValueError("the CSV has no header row")
            text_column = pick_column(headers, args.text_column, TEXT_COLUMNS)
            if text_column is None:
                raise ValueError(f"could not find an email text column; available columns: {', '.join(headers)}")
            label_column = pick_column(headers, args.label_column, LABEL_COLUMNS)
            rows = list(reader)
            if args.limit is not None:
                rows = rows[: max(args.limit, 0)]
        report = analyze_rows(rows, text_column, label_column, max(args.threshold, 0))
        report["text_column"] = text_column
        report["label_column"] = label_column
    except (OSError, UnicodeError, csv.Error, ValueError) as error:
        parser.error(str(error))

    rendered = json.dumps(report, indent=2, ensure_ascii=False)
    print(rendered)
    if args.out:
        try:
            Path(args.out).write_text(rendered + "\n", encoding="utf-8")
        except OSError as error:
            parser.error(f"could not write report: {error}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
