# Phishing Email Detection

A local-first Python 3.10+ prototype that screens `.eml` files or pasted email text for explainable phishing indicators. It uses only the Python standard library and does not send email contents to a service.

## Screen one email

```powershell
python phishing_detector.py suspicious.eml
```

For pasted text, pipe it into the program or use `--sender` to include the sender address:

```powershell
Get-Content email.txt -Raw | python phishing_detector.py - --sender 'Support Team <help@example.com>'
```

Use `--json` for structured output. The detector reports a low, suspicious, or high risk assessment, the points behind it, and link domains. Its rules look for pressure tactics, requests for sensitive details or payment, authentication failures, deceptive link text, unusual link destinations, brand and sender mismatches, and executable attachments.

## Summarize an email dataset

The CSV needs a header and one email-text column. Common names such as `email`, `message`, `body`, `text`, and `content` are detected automatically. If available, a label column named `label`, `class`, `target`, `category`, or `is_phishing` is used for a basic evaluation.

```powershell
python analyze_dataset.py emails.csv
```

To name columns explicitly or save the aggregate report:

```powershell
python analyze_dataset.py emails.csv --text-column message --label-column label --out report.json
```

Recognized phishing labels include `phishing`, `phish`, `malicious`, and `1`; recognized legitimate labels include `legitimate`, `legit`, `ham`, `benign`, and `0`. Unrecognized labels are omitted from the evaluation metrics. The report contains counts and aggregate metrics, not email bodies.

## Risk score

Each detected indicator adds points. A score below 3 is low, 3–6 is suspicious, and 7 or above is high. Dataset evaluation treats a score of 3 or above as a positive phishing detection by default; tune this with `--threshold` after examining validation results.

This is a screening prototype, not a production mail gateway. It does not establish sender authenticity on its own, inspect remote web pages, or prove that messages labeled low risk are safe. Validate it on representative, labeled data before relying on it, and review false positives and false negatives.
