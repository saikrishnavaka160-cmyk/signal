#!/usr/bin/env python3
"""Explainable, local-first phishing email screening prototype."""

from __future__ import annotations

import argparse
from email import policy
from email.parser import Parser
from email.utils import parseaddr
from html.parser import HTMLParser
import ipaddress
import json
import re
import sys
from urllib.parse import urlsplit


URL_PATTERN = re.compile(r"""(?i)\b(?:https?://|www\.)[^\s<>"']+""")
URL_ENDING_PUNCTUATION = ".,;:!?)]}"
SHORTENER_DOMAINS = {
    "bit.ly", "buff.ly", "cutt.ly", "is.gd", "ow.ly", "rb.gy",
    "rebrand.ly", "shorturl.at", "t.co", "tinyurl.com", "urlz.fr",
}
BRAND_DOMAINS = {
    "amazon": ("amazon.com", "amazon.co.uk", "amazon.in"),
    "apple": ("apple.com", "icloud.com"),
    "google": ("google.com", "googlemail.com"),
    "microsoft": ("microsoft.com", "microsoftonline.com"),
    "paypal": ("paypal.com",),
    "netflix": ("netflix.com",),
}
URGENCY_PATTERN = re.compile(
    r"\b(?:urgent|immediately|action required|final notice|within\s+\d+\s+hours?|"
    r"account (?:will be )?(?:suspended|closed|locked)|unusual (?:sign[- ]in|activity)|"
    r"limited time|avoid (?:interruption|suspension))\b",
    re.IGNORECASE,
)
CREDENTIAL_PATTERN = re.compile(
    r"\b(?:password|login credentials|sign in to|verify your account|confirm your identity|"
    r"one[- ]time (?:password|code)|security code|social security number|bank details|"
    r"credit card details)\b",
    re.IGNORECASE,
)
PAYMENT_PATTERN = re.compile(
    r"\b(?:wire transfer|gift card|payment overdue|invoice attached|update (?:your )?payment|"
    r"refund pending|payment failed)\b",
    re.IGNORECASE,
)
AUTH_FAILURE_PATTERN = re.compile(r"\b(?:spf|dkim|dmarc)=(?:fail|softfail|permerror)\b", re.IGNORECASE)
RISKY_ATTACHMENT_EXTENSIONS = {
    ".ade", ".adp", ".app", ".bat", ".cmd", ".com", ".cpl", ".dll", ".exe",
    ".hta", ".iso", ".js", ".jse", ".lnk", ".msi", ".ps1", ".scr", ".vbe",
    ".vbs", ".wsf",
}


class EmailHTMLParser(HTMLParser):
    """Collect visible text and link labels without executing email HTML."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.text_parts: list[str] = []
        self.anchors: list[dict[str, str]] = []
        self._anchor_href: str | None = None
        self._anchor_text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            self._anchor_href = dict(attrs).get("href") or ""
            self._anchor_text = []

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._anchor_href is not None:
            self.anchors.append({"href": self._anchor_href, "text": " ".join(self._anchor_text)})
            self._anchor_href = None
            self._anchor_text = []

    def handle_data(self, data: str) -> None:
        if data.strip():
            self.text_parts.append(data.strip())
            if self._anchor_href is not None:
                self._anchor_text.append(data.strip())


def _message_content(message) -> tuple[str, list[str], list[str]]:
    plain_parts: list[str] = []
    html_parts: list[str] = []
    attachments: list[str] = []

    for part in message.walk():
        filename = part.get_filename()
        if filename:
            attachments.append(filename)
        if part.is_multipart():
            continue
        content_type = part.get_content_type()
        try:
            content = part.get_content()
        except (LookupError, UnicodeError, AttributeError):
            payload = part.get_payload(decode=True)
            content = payload.decode("utf-8", errors="replace") if payload else ""
        if not isinstance(content, str):
            continue
        if content_type == "text/plain":
            plain_parts.append(content)
        elif content_type == "text/html":
            html_parts.append(content)

    html_parser = EmailHTMLParser()
    for fragment in html_parts:
        try:
            html_parser.feed(fragment)
        except Exception:
            # Malformed HTML should not stop the rest of the message from being checked.
            continue
    text = "\n".join(plain_parts + html_parser.text_parts)
    return text, html_parts, attachments


def _clean_url(value: str) -> str:
    return value.rstrip(URL_ENDING_PUNCTUATION)


def _host_for_url(value: str) -> str | None:
    value = _clean_url(value.strip())
    if not re.match(r"^[a-z][a-z0-9+.-]*://", value, re.IGNORECASE):
        first_component = value.split("/", 1)[0]
        if " " in first_component or "." not in first_component:
            return None
        value = "http://" + value
    try:
        parsed = urlsplit(value)
        host = parsed.hostname
        return host.rstrip(".").lower() if host else None
    except ValueError:
        return None


def _domain_matches(host: str, domain: str) -> bool:
    return host == domain or host.endswith("." + domain)


def _displayed_domain(text: str) -> str | None:
    match = URL_PATTERN.search(text.strip())
    candidate = match.group(0) if match else text.strip()
    if not candidate or " " in candidate:
        return None
    if "." not in candidate or candidate.startswith("/"):
        return None
    return _host_for_url(candidate)


def analyze_email(raw_email: str, sender_override: str | None = None) -> dict:
    message = Parser(policy=policy.default).parsestr(raw_email)
    body, html_parts, attachments = _message_content(message)
    if not body:
        body = raw_email
    sender_header = sender_override or str(message.get("From", ""))
    display_name, sender_address = parseaddr(sender_header)
    sender_domain = sender_address.rsplit("@", 1)[-1].lower().rstrip(".") if "@" in sender_address else ""
    subject = str(message.get("Subject", ""))
    detector_text = "\n".join((subject, body))
    full_text = "\n".join((sender_header, detector_text))
    signals: list[dict[str, object]] = []

    def add_signal(code: str, points: int, description: str) -> None:
        if not any(signal["code"] == code for signal in signals):
            signals.append({"code": code, "points": points, "description": description})

    if URGENCY_PATTERN.search(detector_text):
        add_signal("urgent_language", 2, "Uses urgent or threatening language to pressure a quick response.")
    if CREDENTIAL_PATTERN.search(detector_text):
        add_signal("credential_request", 2, "Mentions passwords, sign-in details, or sensitive identity information.")
    if PAYMENT_PATTERN.search(detector_text):
        add_signal("payment_request", 2, "Mentions a payment, transfer, refund, or payment update.")

    auth_headers = " ".join(str(value) for value in message.get_all("Authentication-Results", []))
    auth_headers += " " + " ".join(str(value) for value in message.get_all("ARC-Authentication-Results", []))
    if AUTH_FAILURE_PATTERN.search(auth_headers):
        add_signal("authentication_failure", 3, "An authentication-results header reports SPF, DKIM, or DMARC failure.")

    parser = EmailHTMLParser()
    for fragment in html_parts:
        try:
            parser.feed(fragment)
        except Exception:
            continue
    href_urls = [anchor["href"] for anchor in parser.anchors if anchor.get("href", "").lower().startswith(("http://", "https://", "www."))]
    all_urls = [_clean_url(match.group(0)) for match in URL_PATTERN.finditer(full_text)] + href_urls
    unique_urls = list(dict.fromkeys(url for url in all_urls if _host_for_url(url)))
    hosts = list(dict.fromkeys(host for url in unique_urls if (host := _host_for_url(url))))

    for anchor in parser.anchors:
        href = anchor.get("href", "")
        target_host = _host_for_url(href)
        shown_host = _displayed_domain(anchor.get("text", ""))
        if target_host and shown_host and not (
            _domain_matches(target_host, shown_host) or _domain_matches(shown_host, target_host)
        ):
            add_signal("link_text_mismatch", 3, "A link's displayed domain differs from its destination domain.")
            break

    for host in hosts:
        try:
            ipaddress.ip_address(host)
            add_signal("ip_address_link", 3, "A link uses a raw IP address instead of a domain name.")
            break
        except ValueError:
            pass
    if any(_domain_matches(host, domain) for host in hosts for domain in SHORTENER_DOMAINS):
        add_signal("shortened_link", 2, "A link uses a URL-shortening service that hides its final destination.")
    if any(any(label.startswith("xn--") for label in host.split(".")) or any(ord(char) > 127 for char in host) for host in hosts):
        add_signal("unusual_domain_encoding", 2, "A link uses an internationalized or punycode domain that merits review.")
    if any(urlsplit(url if not url.lower().startswith("www.") else "http://" + url).scheme == "http" for url in unique_urls):
        add_signal("unencrypted_link", 1, "At least one link uses unencrypted HTTP.")

    if display_name and sender_domain:
        lowered_name = display_name.casefold()
        for brand, official_domains in BRAND_DOMAINS.items():
            if brand in lowered_name and not any(_domain_matches(sender_domain, domain) for domain in official_domains):
                add_signal(
                    "brand_sender_mismatch",
                    2,
                    f"The sender display name mentions {brand.title()}, but the sender domain is {sender_domain}.",
                )
                break

    risky_files = [name for name in attachments if any(name.lower().endswith(ext) for ext in RISKY_ATTACHMENT_EXTENSIONS)]
    if risky_files:
        add_signal("risky_attachment", 3, "The message includes an attachment type that can run code or scripts.")

    score = sum(int(signal["points"]) for signal in signals)
    risk = "High" if score >= 7 else "Suspicious" if score >= 3 else "Low"
    return {
        "risk": risk,
        "score": score,
        "sender": sender_header or None,
        "sender_domain": sender_domain or None,
        "signals": signals,
        "link_domains": hosts,
        "attachment_names": attachments,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Screen an email for explainable phishing indicators.")
    parser.add_argument("input", nargs="?", default="-", help="Email text or .eml file path; use - for standard input.")
    parser.add_argument("--sender", help="Optional sender address or display name for plain-text input.")
    parser.add_argument("--json", action="store_true", help="Print the result as JSON.")
    args = parser.parse_args()

    try:
        raw_email = sys.stdin.read() if args.input == "-" else open(args.input, encoding="utf-8", errors="replace").read()
    except OSError as error:
        parser.error(f"could not read input: {error}")
    result = analyze_email(raw_email, args.sender)

    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0

    print(f"Assessment: {result['risk']} risk (score {result['score']})")
    if result["sender"]:
        print(f"Sender: {result['sender']}")
    if result["signals"]:
        print("Indicators:")
        for signal in result["signals"]:
            print(f"  +{signal['points']}  {signal['description']}")
    else:
        print("No strong indicators were found by these rules.")
    if result["link_domains"]:
        print("Link domains: " + ", ".join(result["link_domains"]))
    if result["attachment_names"]:
        print("Attachments: " + ", ".join(result["attachment_names"]))
    print("This screening is heuristic and cannot prove that an email is safe or malicious.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
