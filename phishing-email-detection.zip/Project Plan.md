# Phishing Email Detection — Project Plan

## Goal

Build a transparent tool that helps people and small teams spot suspicious email, explains which clues affected each decision, and can be evaluated against a labeled email dataset.

## First version

- Read `.eml` files and plain-text email content locally.
- Flag common warning signs: urgent pressure, requests for credentials or payment, failed SPF/DKIM/DMARC results, links whose displayed domain differs from their destination, unusual or shortened domains, suspicious sender-brand combinations, and executable attachments.
- Return a risk band, a score, and plain-language reasons for every finding.
- Summarize CSV datasets and, when labels are present, report confusion counts, accuracy, precision, recall, and F1.
- Keep message contents on the user's machine and make the scoring rules visible.

## Data needed

For a meaningful dataset review, provide a CSV with one email per row, an email body or complete message column, and a label column indicating phishing or legitimate mail. Include representative examples from the intended mailbox or audience, remove data that should not be shared, and preserve a separate holdout set for evaluation. The current project folder does not contain a dataset, so dataset-specific findings remain pending.

## Evaluation approach

1. Inspect dataset columns, label definitions, missing values, and class balance.
2. Check for duplicate emails and possible train/test leakage before measuring performance.
3. Run the transparent rule set and report false positives and false negatives alongside summary metrics.
4. Adjust weights and thresholds using training/validation data only; report final metrics on an untouched holdout set.
5. Review errors by signal type and keep a concise record of rule changes.

For imbalanced datasets, prioritize precision and recall (and the confusion matrix) over accuracy alone. The current CSV utility reports aggregate counts and metrics; it does not yet deduplicate, split data, or train a statistical model.

## Milestones

1. **Prototype:** local email screening, explanations, and CSV summary/evaluation.
2. **Dataset review:** inspect the supplied dataset, confirm column and label meanings, and establish a baseline.
3. **Calibration:** tune rules and the decision threshold against validation examples; document trade-offs.
4. **Pilot:** run alongside existing email controls, collect user feedback, and monitor false positives and misses.
5. **Production decision:** only after a successful pilot, decide whether to integrate with a mail client, add a trained model, or keep the lightweight rule-based tool.

## Risks and limits

- A rule-based score can miss new attacks and can flag legitimate urgent or payment-related messages.
- Email authentication results may be absent or forged in forwarded or copied text; they need to be interpreted in the mail system's trusted context.
- Link and sender checks use simple domain rules and cannot reliably identify every lookalike domain or compromised legitimate account.
- A low-risk result is not proof of safety. Keep normal security controls and a way to report suspicious mail.
- Email datasets can contain personal or confidential information; handle them under the organization's data rules and use local processing where possible.
